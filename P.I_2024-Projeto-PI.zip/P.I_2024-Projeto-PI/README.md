BD_LOG - Consulta de dados no SQLite
Parte de login de usuário concluida em 20/10/2024
Sujestões ( Colocar logins separados dependendo da atividade do usuário no sistema)
Colocar parte do médico
Colocar parte de custos e calculo de valores das consultas para os pacientes 
