package com.example.pi;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EsqueciSenha extends AppCompatActivity {

    private EditText edtEmail;
    private Button btnVerificarEmail;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esqueci_senha);

        edtEmail = findViewById(R.id.txt_email);
        btnVerificarEmail = findViewById(R.id.btn_proximo);
        dbHelper = new DBHelper(this);

        btnVerificarEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtEmail.getText().toString().trim();

                // Verifica se o campo de e-mail não está vazio
                if (!email.isEmpty()) {
                    // Verifica se o e-mail existe no banco de dados
                    boolean emailExists = dbHelper.checkEmailExists(email);

                    if (emailExists) {
                        Toast.makeText(EsqueciSenha.this, "E-mail encontrado.", Toast.LENGTH_SHORT).show();
                        // Aqui você pode implementar a lógica de envio de link de recuperação de senha, etc.
                    } else {
                        Toast.makeText(EsqueciSenha.this, "E-mail não encontrado.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EsqueciSenha.this, "Por favor, insira um e-mail.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
