package com.example.pi;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper extends SQLiteOpenHelper {

    // Banco de dados
    private static final String DATABASE_NAME = "Projeto_PI";
    private static final int DATABASE_VERSION = 1;

    // Tabela de clientes
    private static final String TABLE_CLIENTES = "clientes";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NOME = "nome";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_CPF = "cpf";
    private static final String COLUMN_SENHA = "senha";

    // Construtor
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public boolean checkEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CLIENTES + " WHERE " + COLUMN_EMAIL + "=?", new String[]{email});

        boolean exists = (cursor.getCount() > 0); // Se o cursor retornar algum resultado, o e-mail existe.
        cursor.close();
        db.close();
        return exists;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Criação da tabela de clientes
        String CREATE_CLIENTES_TABLE = "CREATE TABLE " + TABLE_CLIENTES + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOME + " TEXT,"
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_CPF + " TEXT,"
                + COLUMN_SENHA + " TEXT)";
        db.execSQL(CREATE_CLIENTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Atualizar o banco de dados
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLIENTES);
        onCreate(db);
    }

    // Adicionar cliente
    public void addCliente(String nome, String email, String cpf, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();
        String insertSQL = "INSERT INTO " + TABLE_CLIENTES + " (" + COLUMN_NOME + ", " + COLUMN_EMAIL + ", " + COLUMN_CPF + ", " + COLUMN_SENHA + ")"
                + " VALUES (?, ?, ?, ?)";
        db.execSQL(insertSQL, new Object[]{nome, email, cpf, senha});
        db.close();
    }

    // Verificar login
    public boolean checkLogin(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CLIENTES + " WHERE " + COLUMN_EMAIL + "=? AND " + COLUMN_SENHA + "=?", new String[]{email, senha});
        if (cursor.moveToFirst()) {
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }
    }
    public Cursor getAllClientes() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CLIENTES;
        return db.rawQuery(query, null);
    }
}

