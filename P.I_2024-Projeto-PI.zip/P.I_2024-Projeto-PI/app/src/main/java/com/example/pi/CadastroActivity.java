package com.example.pi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText txtNome, txtEmail, txtCpf, txtSenha, txtConfirmarSenha;
    private Button btnCadastrar;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        // Inicializar os campos
        txtNome = findViewById(R.id.txt_usuario);
        txtEmail = findViewById(R.id.txt_email);
        txtCpf = findViewById(R.id.txt_cpf);
        txtSenha = findViewById(R.id.txt_senha);
        txtConfirmarSenha = findViewById(R.id.txt_confirmar_senha);
        btnCadastrar = findViewById(R.id.btn_registrar);

        // Inicializar o DBHelper
        dbHelper = new DBHelper(this);

        // Ação ao clicar em "Cadastrar"
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = txtNome.getText().toString();
                String email = txtEmail.getText().toString();
                String cpf = txtCpf.getText().toString();
                String senha = txtSenha.getText().toString();
                String confirmarSenha = txtConfirmarSenha.getText().toString();

                if (senha.equals(confirmarSenha)) {
                    dbHelper.addCliente(nome, email, cpf, senha);
                    Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                    finish(); // Fechar a activity
                } else {
                    Toast.makeText(CadastroActivity.this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
