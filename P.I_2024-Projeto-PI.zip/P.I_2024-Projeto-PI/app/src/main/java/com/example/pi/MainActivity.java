package com.example.pi;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.text.InputType;

public class MainActivity extends AppCompatActivity {

    private EditText txtUsuario, txtLoginSenha;
    private Button btnLogin;
    private DBHelper dbHelper;
    private static final String TAG = "DB_LOG";
    private ImageButton btnMostrarSenha;
    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        txtUsuario = findViewById(R.id.txt_usuario);
        txtLoginSenha = findViewById(R.id.txt_login_senha);
        btnLogin = findViewById(R.id.bnt_login);
        TextView lblCadastro = findViewById(R.id.lblcadastro);
        TextView lblEsqueci = findViewById(R.id.lblEsqueci);
        btnMostrarSenha = findViewById(R.id.btnMostrarSenha);

        dbHelper = new DBHelper(this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = txtUsuario.getText().toString();
                String senha = txtLoginSenha.getText().toString();

                if (dbHelper.checkLogin(email, senha)) {
                    Toast.makeText(MainActivity.this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show();


                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        lblCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });
        lblEsqueci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EsqueciSenha.class);
                startActivity(intent);
            }
        });

        btnMostrarSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {

                    txtLoginSenha.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    isPasswordVisible = false;
                } else {

                    txtLoginSenha.setInputType(InputType.TYPE_CLASS_TEXT);
                    isPasswordVisible = true;
                }

                // Movimenta o cursor para o final
                txtLoginSenha.setSelection(txtLoginSenha.getText().length());
            }
        });

        consultarDadosClientes();
    }

    private void consultarDadosClientes() {
        Cursor cursor = dbHelper.getAllClientes();

        if (cursor != null && cursor.moveToFirst()) {
            int nomeIndex = cursor.getColumnIndex("nome");
            int emailIndex = cursor.getColumnIndex("email");
            int cpfIndex = cursor.getColumnIndex("cpf");
            int senhaIndex = cursor.getColumnIndex("senha");

            if (nomeIndex != -1 && emailIndex != -1 && cpfIndex != -1 && senhaIndex != -1) {
                do {
                    String nome = cursor.getString(nomeIndex);
                    String email = cursor.getString(emailIndex);
                    String cpf = cursor.getString(cpfIndex);
                    String senha = cursor.getString(senhaIndex);

                    // Exibir os dados no Logcat
                    Log.d(TAG, "Cliente: Nome = " + nome + ", Email = " + email + ", CPF = " + cpf + ", Senha = " + senha);
                } while (cursor.moveToNext());
            } else {
                Log.d(TAG, "Alguma coluna não foi encontrada.");
            }
        } else {
            Log.d(TAG, "Nenhum cliente encontrado no banco de dados.");
        }

        if (cursor != null) {
            cursor.close();
        }
    }
}
